import * as _angular_core from '@angular/core';
import { AfterViewInit, OnDestroy, ElementRef } from '@angular/core';

declare class NgxParticleHeader implements AfterViewInit, OnDestroy {
    readonly bgCanvas: _angular_core.Signal<ElementRef<HTMLCanvasElement> | undefined>;
    private ctx?;
    private rafId;
    private particles;
    private lastTs;
    private resizeObserver?;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private handleResize;
    private seedByArea;
    private initParticles;
    private makeParticle;
    private update;
    private draw;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NgxParticleHeader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NgxParticleHeader, "ngx-particle-header", never, {}, {}, never, ["*"], true, never>;
}

interface NgxJourneyHeroTag {
    readonly icon: string;
    readonly label: string;
}
declare class NgxJourneyHero {
    readonly kicker: _angular_core.InputSignal<string>;
    readonly title: _angular_core.InputSignal<string>;
    readonly subtitle: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly descriptionContinuation: _angular_core.InputSignal<string>;
    readonly tags: _angular_core.InputSignal<readonly NgxJourneyHeroTag[]>;
    readonly artIcon: _angular_core.InputSignal<string>;
    readonly artLabel: _angular_core.InputSignal<string>;
    readonly motionPaused: _angular_core.WritableSignal<boolean>;
    readonly particles: {
        left: number;
        size: number;
        duration: number;
        delay: number;
    }[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NgxJourneyHero, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NgxJourneyHero, "ngx-journey-hero", never, { "kicker": { "alias": "kicker"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "descriptionContinuation": { "alias": "descriptionContinuation"; "required": false; "isSignal": true; }; "tags": { "alias": "tags"; "required": false; "isSignal": true; }; "artIcon": { "alias": "artIcon"; "required": false; "isSignal": true; }; "artLabel": { "alias": "artLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { NgxJourneyHero, NgxParticleHeader };
export type { NgxJourneyHeroTag };
