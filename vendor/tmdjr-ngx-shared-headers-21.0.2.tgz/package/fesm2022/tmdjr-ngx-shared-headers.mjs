import * as i0 from '@angular/core';
import { viewChild, Component, input, signal, ChangeDetectionStrategy } from '@angular/core';
import * as i1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';

class NgxParticleHeader {
    bgCanvas = viewChild('bgCanvas', ...(ngDevMode ? [{ debugName: "bgCanvas" }] : []));
    ctx;
    rafId = 0;
    particles = [];
    lastTs = 0;
    resizeObserver;
    ngAfterViewInit() {
        const canvas = this.bgCanvas()?.nativeElement;
        if (!canvas)
            return;
        this.ctx = canvas.getContext('2d') ?? undefined;
        if (!this.ctx)
            return;
        this.handleResize();
        this.resizeObserver = new ResizeObserver(() => this.handleResize());
        this.resizeObserver.observe(canvas.parentElement);
        this.initParticles();
        this.lastTs = performance.now();
        const loop = (ts) => {
            const dt = Math.min(50, ts - this.lastTs);
            this.lastTs = ts;
            this.update(dt / 1000);
            this.draw();
            this.rafId = requestAnimationFrame(loop);
        };
        this.rafId = requestAnimationFrame(loop);
    }
    ngOnDestroy() {
        if (this.rafId)
            cancelAnimationFrame(this.rafId);
        if (this.resizeObserver)
            this.resizeObserver.disconnect();
    }
    handleResize() {
        const canvas = this.bgCanvas()?.nativeElement;
        const ctx = this.ctx;
        if (!canvas || !ctx)
            return;
        const parent = canvas.parentElement;
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        const width = parent.clientWidth;
        const height = parent.clientHeight;
        canvas.width = Math.max(1, Math.floor(width * dpr));
        canvas.height = Math.max(1, Math.floor(height * dpr));
        canvas.style.width = width + 'px';
        canvas.style.height = height + 'px';
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        this.seedByArea(width, height);
    }
    seedByArea(w, h) {
        const density = 0.0018;
        const target = Math.max(8, Math.min(60, Math.floor(w * h * density)));
        if (this.particles.length > target) {
            this.particles.length = target;
        }
        else {
            while (this.particles.length < target)
                this.particles.push(this.makeParticle(w, h));
        }
    }
    initParticles() {
        const canvas = this.bgCanvas()?.nativeElement;
        if (!canvas)
            return;
        this.particles = [];
        this.seedByArea(canvas.clientWidth, canvas.clientHeight);
    }
    makeParticle(w, h) {
        const speed = 20 + Math.random() * 20;
        const angle = Math.random() * Math.PI * 2;
        const vx = Math.cos(angle) * speed;
        const vy = Math.sin(angle) * speed;
        const r = 0.8 + Math.random() * 1.8;
        const a = 0.25 + Math.random() * 0.45;
        return {
            x: Math.random() * w,
            y: Math.random() * h,
            vx,
            vy,
            r,
            a,
        };
    }
    update(dt) {
        const canvas = this.bgCanvas()?.nativeElement;
        if (!canvas)
            return;
        const w = canvas.clientWidth;
        const h = canvas.clientHeight;
        const margin = 20;
        for (const p of this.particles) {
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            if (p.x < -margin)
                p.x = w + margin;
            if (p.x > w + margin)
                p.x = -margin;
            if (p.y < -margin)
                p.y = h + margin;
            if (p.y > h + margin)
                p.y = -margin;
        }
    }
    draw() {
        const ctx = this.ctx;
        const canvas = this.bgCanvas()?.nativeElement;
        if (!ctx || !canvas)
            return;
        const w = canvas.width;
        const h = canvas.height;
        ctx.clearRect(0, 0, w, h);
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        for (const p of this.particles) {
            ctx.beginPath();
            ctx.fillStyle = `rgba(255,255,255,${(p.a * 0.9).toFixed(3)})`;
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fill();
        }
        const maxDist = 120;
        for (let i = 0; i < this.particles.length; i++) {
            for (let j = i + 1; j < this.particles.length; j++) {
                const a = this.particles[i];
                const b = this.particles[j];
                const dx = a.x - b.x;
                const dy = a.y - b.y;
                const d2 = dx * dx + dy * dy;
                if (d2 < maxDist * maxDist) {
                    const alpha = 0.12 * (1 - Math.sqrt(d2) / maxDist);
                    ctx.strokeStyle = `rgba(255,255,255,${alpha.toFixed(3)})`;
                    ctx.beginPath();
                    ctx.moveTo(a.x, a.y);
                    ctx.lineTo(b.x, b.y);
                    ctx.stroke();
                }
            }
        }
        ctx.restore();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: NgxParticleHeader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.1.0", type: NgxParticleHeader, isStandalone: true, selector: "ngx-particle-header", viewQueries: [{ propertyName: "bgCanvas", first: true, predicate: ["bgCanvas"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div class="header">
      <canvas #bgCanvas class="bg-canvas" aria-hidden="true"></canvas>
      <ng-content />
    </div>
  `, isInline: true, styles: [":host{display:block;width:100%}.header{position:relative;width:100%;display:flex;align-items:center;overflow:hidden;background:linear-gradient(135deg,var(--mat-sys-primary) 0%,var(--mat-sys-surface) 100%);color:var(--mat-sys-on-primary)}.bg-canvas{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:0;mix-blend-mode:soft-light}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: NgxParticleHeader, decorators: [{
            type: Component,
            args: [{ selector: 'ngx-particle-header', template: `
    <div class="header">
      <canvas #bgCanvas class="bg-canvas" aria-hidden="true"></canvas>
      <ng-content />
    </div>
  `, styles: [":host{display:block;width:100%}.header{position:relative;width:100%;display:flex;align-items:center;overflow:hidden;background:linear-gradient(135deg,var(--mat-sys-primary) 0%,var(--mat-sys-surface) 100%);color:var(--mat-sys-on-primary)}.bg-canvas{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:0;mix-blend-mode:soft-light}\n"] }]
        }], propDecorators: { bgCanvas: [{ type: i0.ViewChild, args: ['bgCanvas', { isSignal: true }] }] } });

class NgxJourneyHero {
    kicker = input('', ...(ngDevMode ? [{ debugName: "kicker" }] : []));
    title = input.required(...(ngDevMode ? [{ debugName: "title" }] : []));
    subtitle = input('', ...(ngDevMode ? [{ debugName: "subtitle" }] : []));
    description = input('', ...(ngDevMode ? [{ debugName: "description" }] : []));
    descriptionContinuation = input('', ...(ngDevMode ? [{ debugName: "descriptionContinuation" }] : []));
    tags = input([], ...(ngDevMode ? [{ debugName: "tags" }] : []));
    artIcon = input('auto_stories', ...(ngDevMode ? [{ debugName: "artIcon" }] : []));
    artLabel = input('', ...(ngDevMode ? [{ debugName: "artLabel" }] : []));
    motionPaused = signal(false, ...(ngDevMode ? [{ debugName: "motionPaused" }] : []));
    particles = Array.from({ length: 72 }, (_, index) => ({
        left: 8 + 84 * Math.sqrt(((index * 37) % 100) / 100),
        size: 2 + (index % 4),
        duration: 3.2 + ((index * 7) % 23) / 10,
        delay: -((index * 13) % 53) / 10,
    }));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: NgxJourneyHero, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: NgxJourneyHero, isStandalone: true, selector: "ngx-journey-hero", inputs: { kicker: { classPropertyName: "kicker", publicName: "kicker", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, descriptionContinuation: { classPropertyName: "descriptionContinuation", publicName: "descriptionContinuation", isSignal: true, isRequired: false, transformFunction: null }, tags: { classPropertyName: "tags", publicName: "tags", isSignal: true, isRequired: false, transformFunction: null }, artIcon: { classPropertyName: "artIcon", publicName: "artIcon", isSignal: true, isRequired: false, transformFunction: null }, artLabel: { classPropertyName: "artLabel", publicName: "artLabel", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <header
      class="journey-hero__hero"
      [class.journey-hero__hero--paused]="motionPaused()"
    >
      <div class="journey-hero__embers" aria-hidden="true">
        @for (particle of particles; track $index) {
          <span
            class="journey-hero__particle"
            [style.left.%]="particle.left"
            [style.width.px]="particle.size"
            [style.--ember-size]="particle.size + 'px'"
            [style.animation-duration.s]="particle.duration"
            [style.animation-delay.s]="particle.delay"
          ></span>
        }
      </div>
      <div class="journey-hero__hero-copy">
        <div class="journey-hero__hero-kicker">
          <span></span>{{ kicker() }}
        </div>
        <h1>{{ title() }}@if (subtitle()) {<br /><em>{{ subtitle() }}</em>}</h1>
        <p>
          {{ description() }}
          @if (descriptionContinuation()) {
            <br class="journey-hero__desktop-break" />
            {{ descriptionContinuation() }}
          }
        </p>
        @if (tags().length) {
          <div class="journey-hero__hero-tags">
            @for (tag of tags(); track $index) {
              <span><mat-icon aria-hidden="true">{{ tag.icon }}</mat-icon>{{ tag.label }}</span>
            }
          </div>
        }
      </div>
      <div class="journey-hero__hero-art" aria-hidden="true">
        <div class="journey-hero__orb journey-hero__orb--one"></div>
        <div class="journey-hero__orb journey-hero__orb--two"></div>
        <span class="journey-hero__spark journey-hero__spark--one"
          >✦</span
        ><span class="journey-hero__spark journey-hero__spark--two"
          >✧</span
        >
        <div class="journey-hero__art-card">
          <div class="journey-hero__art-icon">
            <mat-icon>{{ artIcon() }}</mat-icon>
          </div>
          <span>{{ artLabel() }}</span>
          <div class="journey-hero__art-bars">
            <i></i><i></i><i></i><i></i><i></i>
          </div>
          <div class="journey-hero__art-line"></div>
          <div
            class="journey-hero__art-line journey-hero__art-line--short"
          ></div>
        </div>
        <div class="journey-hero__art-check">
          <mat-icon>check</mat-icon>
        </div>
      </div>
      <button
        class="journey-hero__motion-toggle"
        type="button"
        aria-label="Pause hero animation"
        [attr.aria-pressed]="motionPaused()"
        [title]="motionPaused() ? 'Resume hero animation' : 'Pause hero animation'"
        (click)="motionPaused.set(!motionPaused())"
      >
        <mat-icon>{{ motionPaused() ? 'play_arrow' : 'pause' }}</mat-icon>
      </button>
    </header>
  `, isInline: true, styles: [":host{display:block;color:var(--ngx-hero-ink, var(--mat-sys-on-surface))}*{box-sizing:border-box}.journey-hero__hero{position:relative;isolation:isolate;padding:45px clamp(22px,5vw,65px);display:grid;grid-template-columns:minmax(0,1fr) 260px;gap:35px;overflow:hidden;background:var(--ngx-hero-soft, var(--mat-sys-surface-container));border-bottom:1px solid var(--ngx-hero-line, var(--mat-sys-outline-variant))}.journey-hero__embers{position:absolute;inset:0;z-index:-1;pointer-events:none;-webkit-mask-image:linear-gradient(to right,transparent,rgb(0 0 0 / .3) 45%,#000 85%);mask-image:linear-gradient(to right,transparent,rgb(0 0 0 / .3) 45%,#000 85%);background:radial-gradient(ellipse at 95% 115%,color-mix(in srgb,var(--mat-sys-primary) 24%,transparent),transparent 75%),radial-gradient(ellipse at 75% 125%,color-mix(in srgb,var(--mat-sys-tertiary) 16%,transparent),transparent 65%)}.journey-hero__particle{position:absolute;bottom:-12px;height:100%;color:var(--mat-sys-primary);--ember-drift: clamp(48px, 9vw, 140px);animation:journey-hero-ember-rise linear infinite}.journey-hero__particle:before{content:\"\";position:absolute;bottom:0;width:100%;height:var(--ember-size);border-radius:50%;background:currentColor;box-shadow:0 0 6px 1px currentColor,0 0 15px 3px color-mix(in srgb,currentColor 35%,transparent)}.journey-hero__particle:nth-child(3n){color:var(--mat-sys-tertiary)}.journey-hero__particle:nth-child(3n+1){color:var(--mat-sys-secondary)}@keyframes journey-hero-ember-rise{0%{transform:translateZ(0);opacity:0}12%{opacity:.65}30%{transform:translate3d(calc(var(--ember-drift) * .4),-30%,0)}50%{transform:translate3d(calc(var(--ember-drift) * .3),-50%,0);opacity:.5}75%{transform:translate3d(calc(var(--ember-drift) * .85),-75%,0);opacity:.3}to{transform:translate3d(var(--ember-drift),-110%,0);opacity:0}}.journey-hero__motion-toggle{position:absolute;right:12px;bottom:8px;display:grid;place-items:center;width:36px;height:36px;padding:0;border:1px solid var(--ngx-hero-line, var(--mat-sys-outline-variant));border-radius:50%;background:var(--ngx-hero-panel, var(--mat-sys-surface-container-lowest));color:var(--ngx-hero-muted, var(--mat-sys-on-surface-variant));cursor:pointer}.journey-hero__motion-toggle:focus-visible{outline:2px solid var(--ngx-hero-accent, var(--mat-sys-primary));outline-offset:3px}.journey-hero__motion-toggle mat-icon{font-size:18px;width:18px;height:18px}.journey-hero__hero--paused .journey-hero__particle,.journey-hero__hero--paused .journey-hero__hero-art{animation-play-state:paused}.journey-hero__hero-kicker{display:flex;align-items:center;gap:9px;font-size:9px;font-weight:750;letter-spacing:2.5px;color:var(--ngx-hero-muted, var(--mat-sys-on-surface-variant))}.journey-hero__hero-kicker>span{width:6px;height:6px;background:var(--ngx-hero-soft, var(--mat-sys-surface-container));border-radius:50%}h1{font-size:clamp(32px,4.5vw,53px);font-weight:500;letter-spacing:-2px;line-height:1.13;margin:23px 0 20px}h1 em{font-family:Georgia,serif;font-weight:400;color:var(--ngx-hero-accent, var(--mat-sys-primary))}.journey-hero__hero-copy p{color:var(--ngx-hero-muted, var(--mat-sys-on-surface-variant));font-size:13px;line-height:1.8;margin:0}.journey-hero__hero-tags{display:flex;gap:25px;margin-top:23px;color:var(--ngx-hero-muted, var(--mat-sys-on-surface-variant));font-size:10px}.journey-hero__hero-tags span{display:flex;gap:6px;align-items:center}.journey-hero__hero-tags mat-icon{font-size:15px;width:15px;height:15px}.journey-hero__hero-art{position:relative;display:grid;place-items:center;min-height:240px;animation:journey-hero-art-sway 7s ease-in-out infinite}@keyframes journey-hero-art-sway{0%,to{translate:-4px 3px;rotate:-1deg}50%{translate:8px -7px;rotate:1.5deg}}.journey-hero__orb{position:absolute;border-radius:50%}.journey-hero__orb--one{background:var(--ngx-hero-primary-soft, var(--mat-sys-primary-container));width:210px;height:210px;right:0;top:32px}.journey-hero__orb--two{border:1px solid var(--ngx-hero-line, var(--mat-sys-outline-variant));width:235px;height:235px;left:0;top:5px}.journey-hero__art-card{position:relative;width:156px;height:187px;background:var(--ngx-hero-panel, var(--mat-sys-surface-container-lowest));box-shadow:0 16px 28px color-mix(in srgb,var(--mat-sys-shadow) 12%,transparent);border-radius:15px;padding:19px;transform:rotate(-9deg)}.journey-hero__art-icon{width:32px;height:32px;display:grid;place-items:center;border-radius:9px;background:var(--ngx-hero-primary-soft, var(--mat-sys-primary-container));color:var(--ngx-hero-on-primary-soft, var(--mat-sys-on-primary-container));margin-bottom:13px}.journey-hero__art-card>span{font-size:6px;letter-spacing:1px;color:var(--ngx-hero-muted, var(--mat-sys-on-surface-variant))}.journey-hero__art-bars{display:flex;align-items:flex-end;gap:7px;height:50px;margin:12px 0}.journey-hero__art-bars i{width:18px;background:var(--ngx-hero-primary-soft, var(--mat-sys-primary-container));border-radius:4px 4px 0 0;height:25%}.journey-hero__art-bars i:nth-child(2){height:44%}.journey-hero__art-bars i:nth-child(3){height:58%;background:color-mix(in srgb,var(--ngx-hero-accent, var(--mat-sys-primary)) 40%,var(--ngx-hero-primary-soft, var(--mat-sys-primary-container)))}.journey-hero__art-bars i:nth-child(4){height:76%;background:color-mix(in srgb,var(--ngx-hero-accent, var(--mat-sys-primary)) 70%,var(--ngx-hero-primary-soft, var(--mat-sys-primary-container)))}.journey-hero__art-bars i:nth-child(5){height:100%;background:var(--ngx-hero-accent, var(--mat-sys-primary))}.journey-hero__art-line{height:4px;border-radius:4px;background:var(--ngx-hero-soft, var(--mat-sys-surface-container));width:100%;margin-top:7px}.journey-hero__art-line.journey-hero__art-line--short{width:65%}.journey-hero__art-check{position:absolute;bottom:40px;right:20px;width:44px;height:44px;display:grid;place-items:center;background:var(--ngx-hero-accent, var(--mat-sys-primary));color:var(--mat-sys-on-primary);border:5px solid var(--ngx-hero-line, var(--mat-sys-outline-variant));border-radius:50%}.journey-hero__spark{position:absolute;color:var(--ngx-hero-accent, var(--mat-sys-primary))}.journey-hero__spark--one{top:10px;right:35px;font-size:28px}.journey-hero__spark--two{bottom:22px;left:15px;font-size:33px}@media(max-width:900px){.journey-hero__hero{grid-template-columns:minmax(0,1fr) 190px;gap:20px}.journey-hero__hero-art{transform:scale(.8);transform-origin:center}.journey-hero__hero{padding-top:32px;padding-bottom:32px}}@media(max-width:600px){.journey-hero__particle:nth-child(n+37){display:none}.journey-hero__hero{grid-template-columns:1fr;gap:0;padding-bottom:52px}.journey-hero__hero-art{display:none}h1{font-size:36px}.journey-hero__hero-tags{gap:15px}.journey-hero__desktop-break{display:none}.journey-hero__hero-copy p{font-size:12px}}@media(prefers-reduced-motion:reduce){.journey-hero__embers,.journey-hero__motion-toggle{display:none}.journey-hero__particle,.journey-hero__hero-art{animation:none}}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: NgxJourneyHero, decorators: [{
            type: Component,
            args: [{ selector: 'ngx-journey-hero', changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatIconModule], template: `
    <header
      class="journey-hero__hero"
      [class.journey-hero__hero--paused]="motionPaused()"
    >
      <div class="journey-hero__embers" aria-hidden="true">
        @for (particle of particles; track $index) {
          <span
            class="journey-hero__particle"
            [style.left.%]="particle.left"
            [style.width.px]="particle.size"
            [style.--ember-size]="particle.size + 'px'"
            [style.animation-duration.s]="particle.duration"
            [style.animation-delay.s]="particle.delay"
          ></span>
        }
      </div>
      <div class="journey-hero__hero-copy">
        <div class="journey-hero__hero-kicker">
          <span></span>{{ kicker() }}
        </div>
        <h1>{{ title() }}@if (subtitle()) {<br /><em>{{ subtitle() }}</em>}</h1>
        <p>
          {{ description() }}
          @if (descriptionContinuation()) {
            <br class="journey-hero__desktop-break" />
            {{ descriptionContinuation() }}
          }
        </p>
        @if (tags().length) {
          <div class="journey-hero__hero-tags">
            @for (tag of tags(); track $index) {
              <span><mat-icon aria-hidden="true">{{ tag.icon }}</mat-icon>{{ tag.label }}</span>
            }
          </div>
        }
      </div>
      <div class="journey-hero__hero-art" aria-hidden="true">
        <div class="journey-hero__orb journey-hero__orb--one"></div>
        <div class="journey-hero__orb journey-hero__orb--two"></div>
        <span class="journey-hero__spark journey-hero__spark--one"
          >✦</span
        ><span class="journey-hero__spark journey-hero__spark--two"
          >✧</span
        >
        <div class="journey-hero__art-card">
          <div class="journey-hero__art-icon">
            <mat-icon>{{ artIcon() }}</mat-icon>
          </div>
          <span>{{ artLabel() }}</span>
          <div class="journey-hero__art-bars">
            <i></i><i></i><i></i><i></i><i></i>
          </div>
          <div class="journey-hero__art-line"></div>
          <div
            class="journey-hero__art-line journey-hero__art-line--short"
          ></div>
        </div>
        <div class="journey-hero__art-check">
          <mat-icon>check</mat-icon>
        </div>
      </div>
      <button
        class="journey-hero__motion-toggle"
        type="button"
        aria-label="Pause hero animation"
        [attr.aria-pressed]="motionPaused()"
        [title]="motionPaused() ? 'Resume hero animation' : 'Pause hero animation'"
        (click)="motionPaused.set(!motionPaused())"
      >
        <mat-icon>{{ motionPaused() ? 'play_arrow' : 'pause' }}</mat-icon>
      </button>
    </header>
  `, styles: [":host{display:block;color:var(--ngx-hero-ink, var(--mat-sys-on-surface))}*{box-sizing:border-box}.journey-hero__hero{position:relative;isolation:isolate;padding:45px clamp(22px,5vw,65px);display:grid;grid-template-columns:minmax(0,1fr) 260px;gap:35px;overflow:hidden;background:var(--ngx-hero-soft, var(--mat-sys-surface-container));border-bottom:1px solid var(--ngx-hero-line, var(--mat-sys-outline-variant))}.journey-hero__embers{position:absolute;inset:0;z-index:-1;pointer-events:none;-webkit-mask-image:linear-gradient(to right,transparent,rgb(0 0 0 / .3) 45%,#000 85%);mask-image:linear-gradient(to right,transparent,rgb(0 0 0 / .3) 45%,#000 85%);background:radial-gradient(ellipse at 95% 115%,color-mix(in srgb,var(--mat-sys-primary) 24%,transparent),transparent 75%),radial-gradient(ellipse at 75% 125%,color-mix(in srgb,var(--mat-sys-tertiary) 16%,transparent),transparent 65%)}.journey-hero__particle{position:absolute;bottom:-12px;height:100%;color:var(--mat-sys-primary);--ember-drift: clamp(48px, 9vw, 140px);animation:journey-hero-ember-rise linear infinite}.journey-hero__particle:before{content:\"\";position:absolute;bottom:0;width:100%;height:var(--ember-size);border-radius:50%;background:currentColor;box-shadow:0 0 6px 1px currentColor,0 0 15px 3px color-mix(in srgb,currentColor 35%,transparent)}.journey-hero__particle:nth-child(3n){color:var(--mat-sys-tertiary)}.journey-hero__particle:nth-child(3n+1){color:var(--mat-sys-secondary)}@keyframes journey-hero-ember-rise{0%{transform:translateZ(0);opacity:0}12%{opacity:.65}30%{transform:translate3d(calc(var(--ember-drift) * .4),-30%,0)}50%{transform:translate3d(calc(var(--ember-drift) * .3),-50%,0);opacity:.5}75%{transform:translate3d(calc(var(--ember-drift) * .85),-75%,0);opacity:.3}to{transform:translate3d(var(--ember-drift),-110%,0);opacity:0}}.journey-hero__motion-toggle{position:absolute;right:12px;bottom:8px;display:grid;place-items:center;width:36px;height:36px;padding:0;border:1px solid var(--ngx-hero-line, var(--mat-sys-outline-variant));border-radius:50%;background:var(--ngx-hero-panel, var(--mat-sys-surface-container-lowest));color:var(--ngx-hero-muted, var(--mat-sys-on-surface-variant));cursor:pointer}.journey-hero__motion-toggle:focus-visible{outline:2px solid var(--ngx-hero-accent, var(--mat-sys-primary));outline-offset:3px}.journey-hero__motion-toggle mat-icon{font-size:18px;width:18px;height:18px}.journey-hero__hero--paused .journey-hero__particle,.journey-hero__hero--paused .journey-hero__hero-art{animation-play-state:paused}.journey-hero__hero-kicker{display:flex;align-items:center;gap:9px;font-size:9px;font-weight:750;letter-spacing:2.5px;color:var(--ngx-hero-muted, var(--mat-sys-on-surface-variant))}.journey-hero__hero-kicker>span{width:6px;height:6px;background:var(--ngx-hero-soft, var(--mat-sys-surface-container));border-radius:50%}h1{font-size:clamp(32px,4.5vw,53px);font-weight:500;letter-spacing:-2px;line-height:1.13;margin:23px 0 20px}h1 em{font-family:Georgia,serif;font-weight:400;color:var(--ngx-hero-accent, var(--mat-sys-primary))}.journey-hero__hero-copy p{color:var(--ngx-hero-muted, var(--mat-sys-on-surface-variant));font-size:13px;line-height:1.8;margin:0}.journey-hero__hero-tags{display:flex;gap:25px;margin-top:23px;color:var(--ngx-hero-muted, var(--mat-sys-on-surface-variant));font-size:10px}.journey-hero__hero-tags span{display:flex;gap:6px;align-items:center}.journey-hero__hero-tags mat-icon{font-size:15px;width:15px;height:15px}.journey-hero__hero-art{position:relative;display:grid;place-items:center;min-height:240px;animation:journey-hero-art-sway 7s ease-in-out infinite}@keyframes journey-hero-art-sway{0%,to{translate:-4px 3px;rotate:-1deg}50%{translate:8px -7px;rotate:1.5deg}}.journey-hero__orb{position:absolute;border-radius:50%}.journey-hero__orb--one{background:var(--ngx-hero-primary-soft, var(--mat-sys-primary-container));width:210px;height:210px;right:0;top:32px}.journey-hero__orb--two{border:1px solid var(--ngx-hero-line, var(--mat-sys-outline-variant));width:235px;height:235px;left:0;top:5px}.journey-hero__art-card{position:relative;width:156px;height:187px;background:var(--ngx-hero-panel, var(--mat-sys-surface-container-lowest));box-shadow:0 16px 28px color-mix(in srgb,var(--mat-sys-shadow) 12%,transparent);border-radius:15px;padding:19px;transform:rotate(-9deg)}.journey-hero__art-icon{width:32px;height:32px;display:grid;place-items:center;border-radius:9px;background:var(--ngx-hero-primary-soft, var(--mat-sys-primary-container));color:var(--ngx-hero-on-primary-soft, var(--mat-sys-on-primary-container));margin-bottom:13px}.journey-hero__art-card>span{font-size:6px;letter-spacing:1px;color:var(--ngx-hero-muted, var(--mat-sys-on-surface-variant))}.journey-hero__art-bars{display:flex;align-items:flex-end;gap:7px;height:50px;margin:12px 0}.journey-hero__art-bars i{width:18px;background:var(--ngx-hero-primary-soft, var(--mat-sys-primary-container));border-radius:4px 4px 0 0;height:25%}.journey-hero__art-bars i:nth-child(2){height:44%}.journey-hero__art-bars i:nth-child(3){height:58%;background:color-mix(in srgb,var(--ngx-hero-accent, var(--mat-sys-primary)) 40%,var(--ngx-hero-primary-soft, var(--mat-sys-primary-container)))}.journey-hero__art-bars i:nth-child(4){height:76%;background:color-mix(in srgb,var(--ngx-hero-accent, var(--mat-sys-primary)) 70%,var(--ngx-hero-primary-soft, var(--mat-sys-primary-container)))}.journey-hero__art-bars i:nth-child(5){height:100%;background:var(--ngx-hero-accent, var(--mat-sys-primary))}.journey-hero__art-line{height:4px;border-radius:4px;background:var(--ngx-hero-soft, var(--mat-sys-surface-container));width:100%;margin-top:7px}.journey-hero__art-line.journey-hero__art-line--short{width:65%}.journey-hero__art-check{position:absolute;bottom:40px;right:20px;width:44px;height:44px;display:grid;place-items:center;background:var(--ngx-hero-accent, var(--mat-sys-primary));color:var(--mat-sys-on-primary);border:5px solid var(--ngx-hero-line, var(--mat-sys-outline-variant));border-radius:50%}.journey-hero__spark{position:absolute;color:var(--ngx-hero-accent, var(--mat-sys-primary))}.journey-hero__spark--one{top:10px;right:35px;font-size:28px}.journey-hero__spark--two{bottom:22px;left:15px;font-size:33px}@media(max-width:900px){.journey-hero__hero{grid-template-columns:minmax(0,1fr) 190px;gap:20px}.journey-hero__hero-art{transform:scale(.8);transform-origin:center}.journey-hero__hero{padding-top:32px;padding-bottom:32px}}@media(max-width:600px){.journey-hero__particle:nth-child(n+37){display:none}.journey-hero__hero{grid-template-columns:1fr;gap:0;padding-bottom:52px}.journey-hero__hero-art{display:none}h1{font-size:36px}.journey-hero__hero-tags{gap:15px}.journey-hero__desktop-break{display:none}.journey-hero__hero-copy p{font-size:12px}}@media(prefers-reduced-motion:reduce){.journey-hero__embers,.journey-hero__motion-toggle{display:none}.journey-hero__particle,.journey-hero__hero-art{animation:none}}\n"] }]
        }], propDecorators: { kicker: [{ type: i0.Input, args: [{ isSignal: true, alias: "kicker", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], subtitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "subtitle", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], descriptionContinuation: [{ type: i0.Input, args: [{ isSignal: true, alias: "descriptionContinuation", required: false }] }], tags: [{ type: i0.Input, args: [{ isSignal: true, alias: "tags", required: false }] }], artIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "artIcon", required: false }] }], artLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "artLabel", required: false }] }] } });

/*
 * Public API Surface of ngx-shared-headers
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxJourneyHero, NgxParticleHeader };
//# sourceMappingURL=tmdjr-ngx-shared-headers.mjs.map
