# @tmdjr/ngx-shared-headers

Standalone Angular headers. Version 21.0.2 adds `NgxJourneyHero` alongside the
existing `NgxParticleHeader`. Requires Angular and Angular Material ^21.1.0.
The host supplies Material theme tokens and the Material icon font.

## Journey hero

Import `NgxJourneyHero` into your standalone component's `imports`:

```ts
import { NgxJourneyHero, NgxJourneyHeroTag } from '@tmdjr/ngx-shared-headers';

readonly tags: readonly NgxJourneyHeroTag[] = [
  { icon: 'code', label: 'Hands-on practice' },
];
```

```html
<ngx-journey-hero
  kicker="YOUR PRACTICE PATH"
  title="Your coding labs."
  subtitle="Build something next."
  description="Choose a challenge and practice."
  descriptionContinuation="Keep going at your own pace."
  [tags]="tags"
  artIcon="terminal"
  artLabel="YOUR NEXT CHALLENGE"
/>
```

`title` is required. Other text inputs default to empty strings; `tags` defaults
to an empty readonly array and `artIcon` to `auto_stories`. Text is interpolated,
never treated as HTML. Subtitle, continuation break and tags are omitted when empty.
Content changes through Angular inputs; animation state stays local to each hero.

The hero includes 72 right-weighted embers, swaying decorative artwork, an
accessible pause toggle, tablet/phone layouts and reduced-motion support. The
artwork is hidden from assistive technology and on phones. Reduced motion hides
the embers/toggle and disables artwork animation. Its inline view/styles remain
one cohesive component so motion, breakpoints and decorative art stay together.

## Theme overrides

All colors fall back to Material system tokens. Optionally set these CSS custom
properties on the component or an ancestor:

| Override | Material fallback |
| --- | --- |
| `--ngx-hero-ink` | `--mat-sys-on-surface` |
| `--ngx-hero-soft` | `--mat-sys-surface-container` |
| `--ngx-hero-panel` | `--mat-sys-surface-container-lowest` |
| `--ngx-hero-line` | `--mat-sys-outline-variant` |
| `--ngx-hero-muted` | `--mat-sys-on-surface-variant` |
| `--ngx-hero-accent` | `--mat-sys-primary` |
| `--ngx-hero-primary-soft` | `--mat-sys-primary-container` |
| `--ngx-hero-on-primary-soft` | `--mat-sys-on-primary-container` |

Embers also use Material primary, secondary and tertiary colors; artwork uses
Material shadow and on-primary tokens. Typography inherits from the host.

## Build and verify

From the workspace root:

```sh
npm run ngx-shared-headers:build
npm test -- --project=ngx-shared-headers --watch=false
npm pack ./dist/ngx-shared-headers
```

The library uses Angular's unit-test builder with Vitest. Publish the built package
from `dist/ngx-shared-headers` only as part of an authorized release.
