# @tmdjr/ngx-shared-headers

Standalone Angular headers. Version 21.0.3 includes `NgxJourneyHero` alongside the
existing `NgxParticleHeader`. Requires Angular and Angular Material ^21.1.0.
The host supplies Material theme tokens and the Material icon font.

## Journey hero

Import `NgxJourneyHero` into your standalone component's `imports`:

```ts
import { NgxJourneyHero, NgxJourneyHeroTag } from '@tmdjr/ngx-shared-headers';

readonly tags: readonly NgxJourneyHeroTag[] = [
  { icon: 'code', label: 'Hands-on practice' },
];
```

```html
<ngx-journey-hero
  kicker="YOUR PRACTICE PATH"
  title="Your coding labs."
  subtitle="Build something next."
  description="Choose a challenge and practice."
  descriptionContinuation="Keep going at your own pace."
  [tags]="tags"
  artIcon="terminal"
  artLabel="YOUR NEXT CHALLENGE"
/>
```

`title` is required. Other text inputs default to empty strings; `tags` defaults
to an empty readonly array and `artIcon` to `auto_stories`. Text is interpolated,
never treated as HTML. Subtitle, continuation break and tags are omitted when empty.
Content changes through Angular inputs; animation state stays local to each hero.

The hero includes 72 right-weighted embers, swaying decorative artwork, an
accessible pause toggle, tablet/phone layouts and reduced-motion support. The
artwork is hidden from assistive technology and on phones. Reduced motion hides
the embers/toggle and disables artwork animation. Its inline templates and styles are split into
focused layout, background and artwork components.

## Theme overrides

All colors fall back to Material system tokens. Optionally set these CSS custom
properties on the component or an ancestor:

| Override | Material fallback |
| --- | --- |
| `--ngx-hero-ink` | `--mat-sys-on-surface` |
| `--ngx-hero-soft` | `--mat-sys-surface-container` |
| `--ngx-hero-panel` | `--mat-sys-surface-container-lowest` |
| `--ngx-hero-line` | `--mat-sys-outline-variant` |
| `--ngx-hero-muted` | `--mat-sys-on-surface-variant` |
| `--ngx-hero-accent` | `--mat-sys-primary` |
| `--ngx-hero-primary-soft` | `--mat-sys-primary-container` |
| `--ngx-hero-on-primary-soft` | `--mat-sys-on-primary-container` |

Embers also use Material primary, secondary and tertiary colors; artwork uses
Material shadow and on-primary tokens. Typography inherits from the host.

## Build and verify

From the workspace root:

```sh
npm run ngx-shared-headers:build
npm test -- --project=ngx-shared-headers --watch=false
npm pack ./dist/ngx-shared-headers
```

The library uses Angular's unit-test builder with Vitest. Publish the built package
from `dist/ngx-shared-headers` only as part of an authorized release.

## Custom backgrounds and artwork

`NgxHero` is the reusable layout. `NgxJourneyHero` composes it with `NgxHeroEmbers`
and `NgxHeroChapterArt`, retaining its previous inputs and behavior. To supply
your own visuals, import `NgxHero` and project components using these attributes:

```html
<ngx-hero title="Know your skills." subtitle="Shape what’s next.">
  <my-assessment-background heroBackground />
  <my-assessment-art heroArt />
</ngx-hero>
```

The layout accepts the same text and tags inputs. It owns decoration containers,
typography, responsive sizing and pause state. Art is hidden on phones; both slots
are decorative (`aria-hidden`), so keep meaningful content and interactive controls
outside them. No background or illustration is imposed by `NgxHero`. Existing
`NgxHeroEmbers` and `NgxHeroChapterArt` can also be projected independently.

Background components should fill their containing slot (`position: absolute;
inset: 0`). Artwork should fit the 260px by 240px area. Custom CSS animations must
use `animation-play-state: var(--ngx-hero-animation-play-state, running)` and disable
animations under `prefers-reduced-motion: reduce`. This allows the single shared
pause button to control both visuals across Angular style encapsulation. Reduced
motion hides the background and pause button; art components disable their motion.

`motionPaused` is a two-way model input on `NgxHero`. `motionEnabled` defaults to
true; set it to false for static visuals to omit the pause control. Both properties
are independent of the selected visuals. Do not animate a static composition.
